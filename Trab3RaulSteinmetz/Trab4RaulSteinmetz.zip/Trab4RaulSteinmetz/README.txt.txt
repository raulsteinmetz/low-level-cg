Trabalho 4 - Raul Steinmetz

Requisitos cumpridos:

- Básicos (todos)
	- Modelagem matemática do motor e projeção em 3d
	- Permite exibir ou esconder peças em específico
	- Visualização ortográfica (2D) e sobre perspectiva (3D)
	- Visualização por vários ângulos (rotação livre no eixo x, y e z)
- Avançados
	- Ajuste do ângulo entre os dois pistões, quantos graus quiser


Como usar:

- A interação com o programa é bem simples, possuí interface com botões
- Clique nos botões para mudar perspectiva, rotacionar o objeto, mudar o angulo entre os pistões, etc.
- Tudo que é possível fazer é na interface, não tem nenhuma feature dependente de comandos.