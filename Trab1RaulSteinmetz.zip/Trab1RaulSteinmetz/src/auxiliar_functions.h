#ifndef AUXILIAR_FUNCTIONS_H
#define AUXILIAR_FUNCTIONS_H

int calc_position(float percent, int w_h, int screen_width, int screen_height ); // calcular pixel baseado em porcentagem da tela
int distance(int x0, int y0, int x1, int y1); // distancia entre dois pontos

#endif // AUXILIAR_FUNCTIONS_h
